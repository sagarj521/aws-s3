import { useEffect, useState } from 'react';
import Card from '../Card/Card'
import AWS from "aws-sdk";

const Home = () => {
    const [images, setImages] = useState([]);
    const [isDeleted, setIsDelete] = useState(false);

    const s3 = new AWS.S3({
      accessKeyId: process.env.REACT_APP_S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.REACT_APP_S3_SECRET_ACCESS_KEY,
      region: process.env.REACT_APP_S3_REGION,
    });

    useEffect( ()=> {           
      
          s3.listObjects({ Bucket: process.env.REACT_APP_S3_BUCKET_NAME }, (err, data) => {
           
            if (err) console.log(err);
            else {
              const filteredObjects = data.Contents.filter((obj) => {
                const objKey = obj.Key.toLowerCase();
                return objKey.endsWith(".jpg") || objKey.endsWith(".png") || objKey.endsWith(".jpeg");
              });
           
              Promise.all(
                filteredObjects.map((obj) =>
                  s3.getObject({ Bucket: process.env.REACT_APP_S3_BUCKET_NAME, Key: obj.Key }).promise()
                )
              ).then((results) => {
                setImages(
                  results.map((result, i) => ({
                    url: URL.createObjectURL(new Blob([result.Body])),
                    key: filteredObjects[i].Key,
                  }))
                );
                setIsDelete(false)
              });
            }
          });
    }, [isDeleted])

    const deleteHandler = async(key) => {
      try {

        await s3.deleteObject({ Bucket: process.env.REACT_APP_S3_BUCKET_NAME, Key: key }).promise();
        console.log(`Object deleted successfully from bucket ${process.env.REACT_APP_S3_BUCKET_NAME}`);
        setIsDelete(true)
      } catch (error) {
        console.log(`Error deleting object from bucket ${process.env.REACT_APP_S3_BUCKET_NAME}: ${error}`);
      }
    }

    return ( <div>        
        { images && <Card listing = {images} deleteHandler = {deleteHandler}/>}
    </div> );
}
 
export default Home;