import React, { useState } from 'react';
import css from './ImageUpload.module.css'; // import CSS file
import AWS from 'aws-sdk';

const ImageUpload = () => {
  const [selectedFile, setSelectedFile] = useState(null);
  const [fileError, setFileError] = useState('');
  const [fileSuccess, setFileSuccess] = useState('');

  const handleFileSelect = (event) => {
    const file = event.target.files[0];
    const allowedTypes = ['image/png', 'image/jpeg', 'image/gif'];
    
    if (file && allowedTypes.includes(file.type)) {
      setSelectedFile(file);
      setFileError('');
    } else {
      setSelectedFile(null);
      setFileError('Please select a valid image file (PNG, JPG, GIF)');
    }
  };

  const handleImageUpload = async () => {
    // Initialize AWS SDK with your credentials and region
    AWS.config.update({
      accessKeyId: process.env.REACT_APP_S3_ACCESS_KEY_ID,
      secretAccessKey: process.env.REACT_APP_S3_SECRET_ACCESS_KEY,
      region: process.env.REACT_APP_S3_REGION
    });

    // Create S3 instance
    const s3 = new AWS.S3();

    // Define S3 bucket and key where image will be stored
    const keyName = `images/${generateImageName()}_${selectedFile.name}`;

    // Create S3 object and upload image
    const params = {
      Bucket: process.env.REACT_APP_S3_BUCKET_NAME,
      Key: keyName,
      Body: selectedFile,
      ContentType: selectedFile.type,
      ACL: 'public-read'
    };

    try {
      const response = await s3.upload(params).promise();
      // setImageUrl(response.Location);
      setFileSuccess('Image uploaded successfully to S3 bucket!')
      selectedFile("")
    } catch (error) {
      console.error(error);
    }
  }

  const generateImageName = () => {
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const length = 10;
    let result = '';
    for (let i = 0; i < length; i++) {
      result += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return result
  }

  return (
    <div className={css.imageUploadContainer}>
      <h2>Upload an Image</h2>
      <div class={css.fileInputContainer}>
        <label for="fileInput">Choose a file</label>
        <input type="file" id="fileInput" accept="image/*" onChange={handleFileSelect} />
      </div>
      
      {fileError && <p className="error">{fileError}</p>}
      {fileSuccess && <p className="success">{fileSuccess}</p>}
      {selectedFile && (
        <div className={css.imagePreviewContainer}>
          <p>File selected: {selectedFile.name}</p>
          <img src={URL.createObjectURL(selectedFile)} alt="Preview" className="image-preview" />
          <button className={css.btn} onClick={handleImageUpload}>Upload</button>
        </div>
      )}
    </div>)
}
 
export default ImageUpload;