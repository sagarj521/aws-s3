import css from './Card.module.css';

const Card = ({listing, deleteHandler}) => {
    return ( 
        <div className={css.cardListing}>
            { listing && listing.map(item =>
                <div className={css.card}>
                    <img src={item.url} alt="Card Image" />
                    <div className={css.cardInfo}>
                    {/* <h2>Test Image </h2> */}
                    {/* <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed ac lacinia magna. Suspendisse potenti.</p> */}
                    <button className={css.deleteButton} onClick={() => deleteHandler(item.key)}>Delete</button>
                    </div>
                </div>)
            }
        </div>
     );
}
 
export default Card;