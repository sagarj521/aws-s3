import './App.css';
import React from 'react';
import Header from './Header/Header';
import {Route, Routes } from 'react-router-dom';
import About from './About';
import ImageUpload from './ImageUpload';
import Home from './Home';

function App() {
  return (
    <React.Fragment>
      <Header />
      <div className="App">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/add-image" element={<ImageUpload />} />
        </Routes>
      </div>
    </React.Fragment>
  );
}

export default App;
