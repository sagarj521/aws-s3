import React from 'react';
import { Link } from 'react-router-dom';

const Header = () => {
  return (
    <header>
        <div><h3>S3 Bucket</h3></div>
        <nav>        
            <ul>
                <li>
                    <Link to='/' exact>Home</Link>
                    <Link to='/add-image'>Upload Image</Link>
                    <Link to='/about'>About</Link>
                </li>
            </ul>
        </nav>
    </header>
  );
};

export default Header;
